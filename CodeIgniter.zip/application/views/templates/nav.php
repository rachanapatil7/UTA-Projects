<pre><nav class="na">


		<a href="<?php echo base_url() ?>leancont/Homepage1" class="active">Inicio</a>    <a href="<?php echo base_url() ?>leancont/AboutUs">Quienes Somos</a>    <a href="http://rachananpatil.uta.cloud/lean-event/">Blog</a>    <a href="<?php echo base_url() ?>leancont/SignUp">Registrate</a>    <a href="<?php echo base_url() ?>leancont/ContactUs">Contacto</a>    <a href="<?php echo base_url() ?>leancont/Login1">Iniciar Sesion</a>    <a href="<?php echo base_url() ?>leancont/BuyFromUs">Comprar Boletos</a> 


	</nav></pre>
<!DOCTYPE html>
<head>
	<title>LeanEvent</title>
	
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>CSS/leanevent.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

	<body>

		<header>
		<div class="column"><img src="<?php echo base_url(); ?>images1/logo-blanco.png" alt="pic" class="logo"></div>
		<div class="column" id="c2"><strong>LEANEVENTOS</strong></div>
		
	</header>   


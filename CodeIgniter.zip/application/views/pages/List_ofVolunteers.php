<pre><nav class="na">
		<a href="<?php echo base_url() ?>leancont/AgentLeanHome" >Inicio</a>    <a href="<?php echo base_url() ?>leancont/List_of_Volunteers" class="active">Lista de Voluntarios</a>    <a href="<?php echo base_url() ?>leancont/List_of_Foundations">Liste de Fundaciones</a>    <a href="<?php echo base_url() ?>leancont/AddEvent" >Eventos</a>    <a href="<?php echo base_url() ?>leancont/AgentLeanProfile" >Agente</a>    


	<br><br><br><br><br><br><br>
<center>
<caption><b><h1>List of Volunteers</h1></b></caption>

	<table>
	<thead>
		<tr>
			<th class="tc1">nombre de voluntario</th>
			<th class="tc2">correo</th>
			<th class="tc3">telefono</th>
			<th class="tc4">Evento</th>
			<th class="tc5">Responsable</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/user.png" alt="pic" class="mb"></div>
							<div class="column" id="it">Nombre del Voluntario</div></td>
			<td class="tc2">Direccion		</td>
			<td class="tc3">0000-000000</td>
			<td class="tc4">Nombre del Evento</td>
			<td class="tc5">Nombre del Responsible</td>

        </tr>

        <tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/user.png" alt="pic" class="mb"></div>
							<div class="column" id="it">Nombre del Voluntario</div></td>
			<td class="tc2">Direccion		</td>
			<td class="tc3">0000-000000</td>
			<td class="tc4">Nombre del Evento</td>
			<td class="tc5">Nombre del Responsible</td>

        </tr>
        <tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/user.png" alt="pic" class="mb"></div>
							<div class="column" id="it">Nombre del Voluntario</div></td>
			<td class="tc2">Direccion		</td>
			<td class="tc3">0000-000000</td>
			<td class="tc4">Nombre del Evento</td>
			<td class="tc5">Nombre del Responsible</td>

        </tr>
	</tbody>
</table>
</center>
<br><br><br><br><br><br><br><br>
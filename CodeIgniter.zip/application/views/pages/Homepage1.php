<pre><nav class="na">


		<a href="<?php echo base_url(); ?>leancont/Homepage1" class="active">Inicio</a>    <a href="<?php echo base_url(); ?>leancont/AboutUs">Quienes Somos</a>    <a href="http://rachananpatil.uta.cloud/lean-event/">Blog</a>    <a href="<?php echo base_url(); ?>leancont/SignUp">Registrate</a>    <a href="<?php echo base_url(); ?>leancont/ContactUs">Contacto</a>    <a href="<?php echo base_url(); ?>Login/login">Iniciar Sesion</a>    <a href="<?php echo base_url(); ?>leancont/BuyFromUs">Comprar Boletos</a> 


	</nav></pre>



<div class="container">
	<img src="<?php echo base_url(); ?>images1/bannerlean2.jpg" alt="pic" class="imall">
	<img src="<?php echo base_url(); ?>images1/logo-blanco.png" alt="pic" id="img2">
</div>
	<br>
	<br>
	<br>
	<br>
	<br>
<div class="hp3_container">
<strong><div><h2>¿QUÉ HACEMOS?</h2></div></strong>
<center><div><br>
La asociación civil LEAN fue creada con el objetivo de ayudar, a través de acciones concretas, a nuestros conciudadanos en Venezuela ante la grave escasez de medicinas e insumos médicos en que se encuentra el país. Nuestra misión consiste en recolectar ayuda médico sanitaria en delegaciones en España y, a través de agentes de transporte, llevarlos a Venezuela para que otras asociaciones se encarguen de su distribución. De esta manera aportamos nuestro granito de arena ayudando a llevar asistencia humanitaria a Venezuela. Somos una asociación sin fines de lucro, dedicada a la defensa de los Derechos Humanos.
</div></center>
</div>

	<br>
	<br>	
	<br>
	<br>
	<br>
	<br>
	<br>

 <div id="hp4">&emsp;&emsp;&emsp;  478 &emsp;&emsp;&emsp; &emsp;&emsp;&emsp; &nbsp; &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;            60.000 &emsp;&emsp;&emsp; &emsp; &emsp;&emsp;&emsp; &emsp;   &emsp;&emsp;&emsp; &emsp;&emsp; &emsp;&emsp;&emsp;            45<br>
  &emsp; VOLUNTARIOS &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; PERSONAS BENEFICIADAS &emsp;&emsp;&emsp; &emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;  ALIADOS</div>

<div class="container">
	<img src="<?php echo base_url(); ?>images1/bannerabout2.jpg" alt="pic" class="imall">
	<div class="text-block"> 
	    <h4>"La injusticia, en cualquier parte, es una armenaza a la justicia en todas partes."</h4>
	    <p align="right">martin Luter King</p>
  	</div>
</div>
	
	<br>
	<br>
	<br>
	<br>
	<br>
	
	<center><strong><h2>  ALIADOS  </h2></strong></center>
	<br>
	<div class="log">
		<div class="column" id="logo1">
			<img src="<?php echo base_url('images1/logo1.png'); ?>" alt="pic">
		</div>
		
		<div class="column" id="logo2">
			<img src="<?php echo base_url('images1/logo2.png'); ?>" alt="pic">
		</div>

		<div class="column" id="logo3">
			<img src="<?php echo base_url('images1/logo3.png'); ?>" alt="pic">
		</div>
		<div class="column" id="logo4">
			<img src="<?php echo base_url('images1/logo4.png'); ?>" alt="pic">
		</div>
	</div>
	<br><br><br><br><br><br><br>
	<br><br><br><br><br><br><br>
	<br><br><br><br><br><br><br><br>

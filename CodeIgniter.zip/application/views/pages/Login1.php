<pre><nav class="na">


		<a href="<?php echo base_url() ?>leancont/Homepage1" >Inicio</a>    <a href="<?php echo base_url() ?>leancont/AboutUs" >Quienes Somos</a>    <a href="http://rachananpatil.uta.cloud/lean-event/">Blog</a>    <a href="<?php echo base_url() ?>leancont/SignUp">Registrate</a>    <a href="<?php echo base_url() ?>leancont/ContactUs">Contacto</a>    <a href="<?php echo base_url() ?>Login/login" class="active">Iniciar Sesion</a>    <a href="<?php echo base_url() ?>leancont/BuyFromUs">Comprar Boletos</a> 


	</nav></pre>

	<br><br>
	<div class="container">
		<img src="<?php echo base_url(); ?>images1/bannerlogin.jpg" alt="pic" class="imall">
		<div class="text-block1">
			<h1>INICIAR SESION</h1>
	    	<p>INICIO INICIAR SESION </p>
		</div>
	</div>

	
	<br><br><br><br><br>
	<center>
		<form  method="POST" id="l1">
			<h4>Iniciar Sesion</h4>
			<div class="column" id="l2">
				<h5>Nombre de Usuario</h5>
				<input type="text" name="uname" value="" placeholder="Nombre de Usuario o Correo">
			</div>
	  		<div class="column" id="l3">
	  			<h5>Contrasena</h5>
				<input type="password" name="pass" value="" placeholder="Contrasena">
	  		</div>
	  		<div style="clear:both;">&nbsp;</div>
	  		<div id="l4"><a href="#" id="modalBtn">Olvido su contrasena?</a></div>

	  		<div style="clear:both;">&nbsp;</div>
	  		<div id="cu6" align="center">
		<input type="submit" name="enter" value="Entra" class="button" >
	  		</div>

		
	</form></center>

<div id="simpleModal" class="modal">
	<div class="modal-content">
		<span class="close">&times;</span>
		<center>
			
			<div class="pop-up"	>
				<div id="isf2">Recuperar su Contrasena</div><hr><br>
					<div id="isf3">Correo</div><br>
						<input type="text" name="" placeholder="Correo"><br><br><hr><br>
							<div id="clo">
								<button class="clo1">Cerrar</button>	
								<button class="button">Enviar</button>
							</div>
					</div>

	    </center>
	</div>
</div>

	<br><br><br><br><br>
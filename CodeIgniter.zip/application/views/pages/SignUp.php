<pre><nav class="na">


		<a href="<?php echo base_url() ?>leancont/Homepage1" >Inicio</a>    <a href="<?php echo base_url() ?>leancont/AboutUs"  >Quienes Somos</a>    <a href="http://rachananpatil.uta.cloud/lean-event/">Blog</a>    <a href="<?php echo base_url() ?>leancont/SignUp" class="active">Registrate</a>    <a href="<?php echo base_url() ?>leancont/ContactUs">Contacto</a>    <a href="<?php echo base_url() ?>Login/login">Iniciar Sesion</a>    <a href="<?php echo base_url() ?>leancont/BuyFromUs">Comprar Boletos</a> 


	</nav></pre>

	<div class="container">
		<div class="text-block1">
			<h1>REGISTRATE</h1>
	    	<p>INICIO REGISTRATE </p>
		</div>
	</div>                                                  
<img src="<?php echo base_url(); ?>images1/bannerregistro.jpg" alt="pic" class="imall">
	<br>
	<br>
	<br>
	<br>
	<br>

<center>
	<div class="sign_up">
		<h4>Elija el tipo de usuario para registrarse</h4><hr>

		
		<?php echo anchor("register",'Como Individual',['class'=>'button']);  ?> 
		<?php echo anchor("registerbus",'Como Negocio o Fundacion',['class'=>'button']);  ?>
		<?php echo anchor("lean",'Como agente LEAN',['class'=>'button']);  ?>

	</div>
</center>




<br><br><br><br><br><br><br><br><br><br><br><br>
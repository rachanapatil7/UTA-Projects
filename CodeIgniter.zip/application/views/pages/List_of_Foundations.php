<pre><nav class="na">
		<a href="<?php echo base_url() ?>leancont/AgentLeanHome" >Inicio</a>    <a href="<?php echo base_url() ?>leancont/List_of_Volunteers">Lista de Voluntarios</a>    <a href="<?php echo base_url() ?>leancont/List_of_Foundations" class="active">Liste de Fundaciones</a>    <a href="<?php echo base_url() ?>leancont/AddEvent" >Eventos</a>    <a href="<?php echo base_url() ?>leancont/AgentLeanProfile" >Agente</a>    

	
<br><br><br><br><br><br><br>
<center>
<caption><b><h1>Lista de Fundaciones</h1></b></caption>
<br><br><br><br><br>
	<table>
	<thead>
		<tr>
			<th class="tc1">nombre de la fundacion</th>
			<th class="tc2">Evento</th>
			<th class="tc3">Responsable</th>
			<th class="tc4">Comision</th>
			<th class="tc5">Confirmar</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/nologo.png" alt="pic" class="mb"></div>
							<div class="column" id="it">nombre de la fundacion</div></td>
			<td class="tc2">Nombre del Evento		</td>
			<td class="tc3">Nombre del Responsible</td>
			<td class="tc4"><input type="text" name="" value="1"></td>
			<td class="tc5"><input type="submit" value="Asignar" class="button"></td>

        </tr>

       <tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/nologo.png" alt="pic" class="mb"></div>
							<div class="column" id="it">nombre de la fundacion</div></td>
			<td class="tc2">Nombre del Evento		</td>
			<td class="tc3">Nombre del Responsible</td>
			<td class="tc4"><input type="text" name="" value="1"></td>
			<td class="tc5"><input type="submit" value="Asignar" class="button"></td>

        </tr>
        <tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/nologo.png" alt="pic" class="mb"></div>
							<div class="column" id="it">nombre de la fundacion</div></td>
			<td class="tc2">Nombre del Evento		</td>
			<td class="tc3">Nombre del Responsible</td>
			<td class="tc4"><input type="text" name="" value="1"></td>
			<td class="tc5"><input type="submit" value="Asignar" class="button"></td>

        </tr>
	</tbody>
</table>
</center>
<br><br><br><br><br><br><br><br>
	
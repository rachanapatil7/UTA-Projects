<pre><nav class="na">
		<a href="<?php echo base_url() ?>leancont/AgentLeanHome" class="active">Inicio</a>    <a href="<?php echo base_url() ?>leancont/List_of_Volunteers">Lista de Voluntarios</a>    <a href="<?php echo base_url() ?>leancont/List_of_Foundations">Liste de Fundaciones</a>    <a href="<?php echo base_url() ?>Eventos/events" >Eventos</a>    <a href="<?php echo base_url() ?>leancont/AgentLeanProfile">Agente</a>    

	</nav></pre>


	<div class="container">
	<img src="<?php echo base_url(); ?>images1/bannerlean1.jpg" alt="pic" class="imall">
	<img src="<?php echo base_url(); ?>images1/logo-blanco.png" alt="pic" id="img2">
</div>
	<br><br><br>
	<br><br><br>
	<br><br><br>
	<br><br><br>
	<br><br><br>
	<br><br><br>
	<br><br><br>
	

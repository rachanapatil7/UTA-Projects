<pre><nav class="na"><strong>
		<a href="<?php echo base_url() ?>leancont/BussinessHome" class="active">Inicio</a>    <a href="<?php echo base_url() ?>leancont/BussinessProfile">Fundacion</a>    </strong> 

		</nav></pre>

			<br><br><br><br>

	<center><caption><b><h1>Lista de Eventos</h1></b></caption>
		<table>
	<thead>
		<tr>
			<th class="tc1">DETALLES DEL EVENTOS</th>
			<th class="tc2">LUGAR</th>
			<th class="tc3">FECHA</th>
			<th class="tc4">HORA</th>
			<th class="tc5">ASISTENCIA</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/minibaner1.jpg" alt="pic" class="mb"></div>
							<div class="column" id="it">Nombre del Evento y sus detalles</div></td>
			<td class="tc2">	Direccion del lugar	</td>
			<td class="tc3">14/01/2019</td>
			<td class="tc4">8AM</td>
			<td class="tc5"><input type="submit" value="Confirmar" class="button"></td>

        </tr>

        <tr>
			<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/minibaner2.jpg" alt="pic" class="mb"></div>
				            <div class="column" id="it"> Nombre del Evento y sus detalles</div></td>
			<td class="tc2">	Direccion del lugar	</td>
			<td class="tc3">14/01/2019</td>
			<td class="tc4">8AM</td>
			<td class="tc5"><input type="submit" value="Confirmar" class="button"></td>

        </tr>
        <tr>
        	<td class="tc1"><div class="column"><img src="<?php echo base_url() ?>images1/minibaner3.jpg" alt="pic" class="mb"></div>
        		            <div class="column" id="it">Nombre del Evento y sus detalles</div></td>
			<td class="tc2">	Direccion del lugar	</td>
			<td class="tc3">14/01/2019</td>
			<td class="tc4">8AM</td>
			<td class="tc5"><input type="submit" value="Confirmar" class="button"></td>
        </tr>
	</tbody>
</table>
	</center>

<br><br><br><br><br><br><br><br>